# AWS Bedrock API Sample (仮想コード)
import boto3

# Bedrockクライアントの初期化
client = boto3.client('bedrock-runtime')

# モデル呼び出し例（Claudeなど）
response = client.invoke_model(
    modelId='anthropic.claude-v2',
    body='{"prompt": "AWS Bedrockとは？", "max_tokens": 100}',
    contentType='application/json',
    accept='application/json'
)

print(response['body'].read())
