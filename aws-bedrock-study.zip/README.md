# AWS Bedrock Study Session

このリポジトリは、AWS Bedrockの勉強会用資料をまとめたものです。
初心者向けにわかりやすく構成されています。
